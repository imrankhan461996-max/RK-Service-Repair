RK SERVICE & REPAIR - ONE PAGE WEBSITE

Included:
- index.html
- logo.png (uploaded RK Service & Repair logo)

Business details:
- Phone/WhatsApp: 9044648150
- AC service: ₹499
- Visit charges: ₹199
- Service areas: Chandigarh, Mohali, Kharar
- Services: AC, geyser, washing machine, refrigerator/freezer, microwave and other appliances

Open index.html to preview. Upload the complete folder contents to web hosting to publish it.
